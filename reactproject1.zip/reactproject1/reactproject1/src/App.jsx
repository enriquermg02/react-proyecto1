import  ExcelDataUploader  from "./Excel";
import './App.css'

function App() {


  return (
    <>
          Hola como estas ss kjsndksnaldn sss
          <ExcelDataUploader></ExcelDataUploader>
    </>
  )
}

export default App
